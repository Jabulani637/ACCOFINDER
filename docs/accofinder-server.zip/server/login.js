// Place this at: client/scripts/login.js
(() => {
  const form      = document.getElementById("loginForm");
  const emailEl   = document.getElementById("email");
  const passEl    = document.getElementById("password");
  const errorBanner = document.getElementById("errorBanner");
  const submitBtn = document.getElementById("submitBtn");

  function showError(msg) {
    if (!errorBanner) return;
    errorBanner.textContent = msg;
    errorBanner.style.display = "block";
  }

  function hideError() {
    if (errorBanner) errorBanner.style.display = "none";
  }

  form?.addEventListener("submit", async (e) => {
    e.preventDefault();
    hideError();

    const email    = emailEl.value.trim();
    const password = passEl.value;

    if (!email || !password) return;

    submitBtn.disabled = true;
    submitBtn.textContent = "Logging in...";

    try {
      const res = await fetch(`${API_URL}/auth/login`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        showError(data.detail || "Login failed. Please try again.");
        return;
      }

      saveSession(data);

      // Redirect based on role
      const role = data.user.role;
      if (role === "admin")  window.location.href = "admin.html";
      else if (role === "owner") window.location.href = "dashboard.html";
      else window.location.href = "home.html";

    } catch (err) {
      showError("Could not connect to server. Please try again later.");
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "Log in";
    }
  });
})();
