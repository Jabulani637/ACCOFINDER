from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.sql import func
from database import Base

class User(Base):
    __tablename__ = "users"

    id            = Column(Integer, primary_key=True, index=True)
    first_name    = Column(String, nullable=False)
    last_name     = Column(String, nullable=False)
    email         = Column(String, unique=True, index=True, nullable=False)
    phone         = Column(String, nullable=True)
    hashed_password = Column(String, nullable=False)
    role          = Column(String, default="student")   # student | owner | admin
    gender        = Column(String, default="unspecified")
    city          = Column(String, nullable=True)
    created_at    = Column(DateTime(timezone=True), server_default=func.now())
