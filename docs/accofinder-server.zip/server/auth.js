// Base URL — swap this for your Render URL once deployed
const API_URL = "http://127.0.0.1:8000";

// Save token + user to localStorage after login/register
function saveSession(data) {
  localStorage.setItem("token", data.access_token);
  localStorage.setItem("user", JSON.stringify(data.user));
}

function getToken() {
  return localStorage.getItem("token");
}

function getUser() {
  const u = localStorage.getItem("user");
  return u ? JSON.parse(u) : null;
}

function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  window.location.href = "login.html";
}

// Redirect to login if not authenticated
function requireAuth() {
  if (!getToken()) {
    window.location.href = "login.html";
  }
}
