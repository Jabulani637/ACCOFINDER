from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from database import Base, engine
from routes import auth, users
from routes.password_reset import router as reset_router

# Import models so SQLAlchemy registers them before create_all
from models import user, otp  # noqa: F401

# Create all tables on startup
Base.metadata.create_all(bind=engine)

app = FastAPI(title="ACCOFINDER API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://accofinder.vercel.app",
        "http://localhost:5500",
        "http://127.0.0.1:5500",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router,   prefix="/auth",  tags=["Auth"])
app.include_router(users.router,  prefix="/users", tags=["Users"])
app.include_router(reset_router,  prefix="/auth",  tags=["Password Reset"])

@app.get("/")
def root():
    return {"message": "ACCOFINDER API is running"}
