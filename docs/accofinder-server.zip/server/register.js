// Place this at: client/scripts/register.js
(() => {
  const form        = document.getElementById("registerForm");
  const passEl      = document.getElementById("password");
  const confirmEl   = document.getElementById("confirmPassword");
  const hintEl      = document.getElementById("passwordHint");
  const errorBanner = document.getElementById("errorBanner");
  const submitBtn   = document.getElementById("submitBtn");

  function showError(msg) {
    if (!errorBanner) return;
    errorBanner.textContent = msg;
    errorBanner.style.display = "block";
  }

  function hideError() {
    if (errorBanner) errorBanner.style.display = "none";
  }

  const checkPasswords = () => {
    const ok = passEl.value === confirmEl.value;
    if (hintEl) hintEl.style.display = ok ? "none" : "block";
    return ok;
  };

  passEl?.addEventListener("input", checkPasswords);
  confirmEl?.addEventListener("input", checkPasswords);

  form?.addEventListener("submit", async (e) => {
    e.preventDefault();
    hideError();

    if (!checkPasswords()) {
      confirmEl?.focus();
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = "Creating account...";

    const body = {
      first_name: document.getElementById("firstName").value.trim(),
      last_name:  document.getElementById("lastName").value.trim(),
      email:      document.getElementById("email").value.trim(),
      password:   passEl.value,
      phone:      document.getElementById("phone").value.trim(),
      role:       document.getElementById("role").value,
      gender:     document.getElementById("gender").value,
      city:       document.getElementById("city").value,
    };

    try {
      const res = await fetch(`${API_URL}/auth/register`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(body),
      });

      const data = await res.json();

      if (!res.ok) {
        showError(data.detail || "Registration failed. Please try again.");
        return;
      }

      saveSession(data);
      window.location.href = "home.html";

    } catch (err) {
      showError("Could not connect to server. Please try again later.");
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "Sign up";
    }
  });
})();
