import random
import string
from datetime import datetime, timedelta, timezone

OTP_EXPIRY_MINUTES = 10
OTP_LENGTH         = 6

def generate_otp() -> str:
    """Generate a random 6-digit numeric OTP."""
    return "".join(random.choices(string.digits, k=OTP_LENGTH))

def otp_expiry() -> datetime:
    """Return a UTC datetime 10 minutes from now."""
    return datetime.now(timezone.utc) + timedelta(minutes=OTP_EXPIRY_MINUTES)

def is_otp_expired(expires_at: datetime) -> bool:
    """Check if OTP has passed its expiry time."""
    # Make expires_at timezone-aware if it isn't
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    return datetime.now(timezone.utc) > expires_at
