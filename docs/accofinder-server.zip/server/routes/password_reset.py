from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from database import get_db
from models.user import User
from models.otp import OTPCode
from schemas.otp import RequestOTP, VerifyOTP, ResetPassword
from core.otp_utils import generate_otp, otp_expiry, is_otp_expired
from core.security import hash_password
from services.email_service import send_otp_email
from services.sms_service import send_otp_sms

router = APIRouter()


# ── Step 1: User requests an OTP ─────────────────────────────────────────────

@router.post("/request-otp")
def request_otp(body: RequestOTP, db: Session = Depends(get_db)):
    # Look up user by email
    user = db.query(User).filter(User.email == body.email).first()

    # Always return 200 even if user not found (security: don't reveal emails)
    if not user:
        return {"message": "If an account exists, a code has been sent."}

    # Check that we can actually send via the chosen channel
    if body.channel == "sms" and not user.phone:
        raise HTTPException(
            status_code=400,
            detail="No phone number on this account. Please use email instead.",
        )

    # Invalidate any previous unused OTPs for this user + channel
    db.query(OTPCode).filter(
        OTPCode.user_id == user.id,
        OTPCode.channel == body.channel,
        OTPCode.used    == False,
    ).delete()
    db.commit()

    # Generate and store new OTP
    code = generate_otp()
    otp  = OTPCode(
        user_id    = user.id,
        code       = code,
        channel    = body.channel,
        expires_at = otp_expiry(),
    )
    db.add(otp)
    db.commit()

    # Send via chosen channel
    if body.channel == "email":
        sent = send_otp_email(user.email, code, user.first_name)
    else:
        sent = send_otp_sms(user.phone, code)

    if not sent:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to send OTP via {body.channel}. Please try again.",
        )

    return {"message": "If an account exists, a code has been sent."}


# ── Step 2: Verify OTP (optional standalone check before reset) ───────────────

@router.post("/verify-otp")
def verify_otp(body: VerifyOTP, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == body.email).first()
    if not user:
        raise HTTPException(status_code=400, detail="Invalid code.")

    otp = db.query(OTPCode).filter(
        OTPCode.user_id == user.id,
        OTPCode.code    == body.code,
        OTPCode.channel == body.channel,
        OTPCode.used    == False,
    ).first()

    if not otp:
        raise HTTPException(status_code=400, detail="Invalid or already used code.")

    if is_otp_expired(otp.expires_at):
        raise HTTPException(status_code=400, detail="Code has expired. Please request a new one.")

    return {"message": "Code verified.", "valid": True}


# ── Step 3: Reset password using verified OTP ─────────────────────────────────

@router.post("/reset-password")
def reset_password(body: ResetPassword, db: Session = Depends(get_db)):
    if len(body.new_password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters.")

    user = db.query(User).filter(User.email == body.email).first()
    if not user:
        raise HTTPException(status_code=400, detail="Invalid code.")

    otp = db.query(OTPCode).filter(
        OTPCode.user_id == user.id,
        OTPCode.code    == body.code,
        OTPCode.channel == body.channel,
        OTPCode.used    == False,
    ).first()

    if not otp:
        raise HTTPException(status_code=400, detail="Invalid or already used code.")

    if is_otp_expired(otp.expires_at):
        raise HTTPException(status_code=400, detail="Code has expired. Please request a new one.")

    # Mark OTP as used
    otp.used = True

    # Update password
    user.hashed_password = hash_password(body.new_password)

    db.commit()

    return {"message": "Password reset successfully. You can now log in."}
