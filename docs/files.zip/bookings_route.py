# routes/bookings.py — placeholder, will be fully wired when booking feature is built
from fastapi import APIRouter
router = APIRouter()
