# routes/properties.py — placeholder, will be fully wired when properties feature is built
from fastapi import APIRouter
router = APIRouter()
